import React from 'react';
import DieselReport from './Diesel_Report';

const DieselModule = () => {
    return (
        <div>
            <DieselReport />
        </div>
    );
};

export default DieselModule;