import React from 'react';

const IndentManagement = () => {
    return (
        <div>
            Indent Management Module
        </div>
    );
};

export default IndentManagement;