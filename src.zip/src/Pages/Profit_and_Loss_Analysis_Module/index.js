import React from 'react';
import SiteReport from './SiteReport';

const ProfitAndLossAnalysis = () => {
    return (
        <div>
            <SiteReport />
        </div>
    );
};

export default ProfitAndLossAnalysis;