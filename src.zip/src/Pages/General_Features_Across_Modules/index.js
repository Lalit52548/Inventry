import React from 'react';

const GeneralFeature = () => {
    return (
        <div>
            General Feature
        </div>
    );
};

export default GeneralFeature;